#ifndef _ADC_CONFIG_H
#define _ADC_CONFIG_H

#define DAC_REF_SEL      (0)
#define DAC_EXT_REF_GPIO (7)

#endif