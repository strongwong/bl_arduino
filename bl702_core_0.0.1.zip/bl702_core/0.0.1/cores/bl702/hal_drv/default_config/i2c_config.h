#ifndef _I2C_CONFIG_H
#define _I2C_CONFIG_H

#endif