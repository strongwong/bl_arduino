#ifndef _PWM_CONFIG_H
#define _PWM_CONFIG_H

#define PWM_STOP_MODE_SEL (PWM_STOP_GRACEFUL)

#endif