#ifndef _TIMER_CONFIG_H
#define _TIMER_CONFIG_H

#define TIMER_CLK_SRC (0)

#endif